CREATE FUNCTION bit_length(bit)
  RETURNS integer
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.length($1)
$$;

