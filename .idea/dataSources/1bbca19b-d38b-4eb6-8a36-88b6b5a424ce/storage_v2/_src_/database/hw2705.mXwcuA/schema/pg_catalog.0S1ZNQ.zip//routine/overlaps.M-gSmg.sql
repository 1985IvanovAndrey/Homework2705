CREATE FUNCTION "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval)
  RETURNS boolean
STABLE
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

