CREATE FUNCTION timetzdate_pl(time with time zone, date)
  RETURNS timestamp with time zone
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($2 + $1)
$$;

